//############################################################################
//
// LaserBoy !!!
//
// by James Lehman
// Extra Stimulus Inc.
// james@akrobiz.com
//
// began: October 2003
//
// Copyright 2003, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 2017 James Lehman.
// This source is distributed under the terms of the GNU General Public License.
//
// LaserBoy.cpp is part of LaserBoy.
//
// LaserBoy is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LaserBoy is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LaserBoy. If not, see <http://www.gnu.org/licenses/>.
//
//############################################################################
#include "LaserBoy_SDL_GUI.hpp"

//############################################################################
int main(int argc, char *argv[])
{
    int xres = 640,
        yres = 480;

    if(argc >= 3)
    {
        xres = atoi(argv[1]);
        yres = atoi(argv[2]);
    }

    LaserBoy_SDL_GUI LaserBoy_App(xres, yres);

    return LaserBoy_App.start_menu_loop();
}

//############################################################################
//////////////////////////////////////////////////////////////////////////////
//############################################################################
